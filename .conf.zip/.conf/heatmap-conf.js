heatmapConfig = {
  "Mappings": {
    "Einddatum contract": {
      "propertyName": "Einddatum contract",
      "coloringType": "FillColoring",
      "colors": {
        "": "#c0c0c0"
      }
    },
    "State": {
      "propertyName": "State",
      "coloringType": "FillColoring",
      "colors": {
        "Current": "#ff80ff",
        "New": "#0080ff",
        "Obsolete": "#ff0000"
      }
    },
    "Webadres": {
      "propertyName": "Webadres",
      "coloringType": "FillColoring",
      "colors": {
        "": "#00ffff",
        "https://www.topdesk.com/": "#80ffff"
      }
    },
    "Rol": {
      "propertyName": "Rol",
      "coloringType": "FillColoring",
      "colors": {
        "A": "#800000",
        "B": "#804040"
      }
    },
    "Eigenaar2": {
      "propertyName": "Eigenaar",
      "coloringType": "FillColoring",
      "colors": {
        "Directeur Bedrijfsvoering": "#ff8080",
        "Manager F&C": "#ff8080",
        "Directeur Behandeling & Verblijf": "#ff8040",
        "Directeur Ambulant": "#ff8040",
        "Manager PIT": "#ff00ff",
        "Manager Services, Vastgoed en Inkoop": "#ff8080",
        "Directeur M&O": "#80ff80",
        "Directeur BOJ": "#ffff80",
        "Directeur": "#8000ff",
        "Manager zorgcontractering": "#ffff80",
        "Manager Kwaliteit & WO": "#80ff80",
        "Raad van Bestuur": "#8000ff",
        "Manager Leerwerkbedrijf": "#ffff80",
        "Manager service- en expertisecentrum M&O": "#80ff80",
        "Transitiedirecteur": "#8000ff",
        "Kwaliteitsmanager": "#ff8080",
        "Eigenaar \"groepen tenzij\"": "#ffffff"
      }
    },
    "Cap2 Map": {
      "propertyName": "Cap2",
      "coloringType": "FillColoring",
      "colors": {
        "Psychotherapie": "#80ffff",
        "ICT": "#c0c0c0",
        "Financiele afhandeling": "#0080ff",
        "Farmacotherapie": "#80ff00",
        "Zorgverlening": "#80ff80",
        "Kwaliteitsmanagement": "#ff0000",
        "Verpleging": "#80ff80",
        "Diagnose": "#80ff80",
        "Relatiebeheer": "#008080",
        "Facilitair beheer": "#808000",
        "Personeelsmanagement": "#008000",
        "Communicatie": "#008000",
        "Aanmelding en screening": "#80ff80",
        "Financien": "#0080ff",
        "Onderwijs": "#ff8040",
        "Onderzoek": "#ff8040",
        "Resourceplanning": "#80ff80",
        "Inkoop": "#808000",
        "Zorgcontractering": "#80ff80",
        "Intake": "#80ff80",
        "Planning & Control": "#ffff80",
        "Verwijzingen ontvangen": "#80ff80",
        "Security Management": "#ff80ff",
        "Evaluatie": "#80ff80",
        "Begeleiding": "#80ff80"
      }
    },
    "State Map": {
      "propertyName": "State",
      "coloringType": "FontColoring",
      "colors": {
        "Obsolete": "#ff0000",
        "Target": "#008000"
      }
    }
  }
};